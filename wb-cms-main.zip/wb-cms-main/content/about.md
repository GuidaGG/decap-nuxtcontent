---
title: Welcome to My Site
tagline: This is a simple homepage powered by Nuxt Content.
buttonText: Learn More
buttonLink: /about
sections:
  - type: hero
    heading: This it the Other Page
    subheading: Hihihihihi
    image: /uploads/img1.jpg
  - type: text
    heading: About Us
    content: 
      Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.
---


# Hello 👋

This content is written in **Markdown** and stored in the `content/` folder.

Nuxt Content lets you write your site easily, with full support for front-matter.

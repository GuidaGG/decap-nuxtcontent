---
title: Homepage
tagline: This is a simple homepage powered by Nuxt Content.
buttonText: Learn More
buttonLink: /about
sections:
  - type: hero
    heading: Guida Nuxt Content with CMS
    subheading: This is a small prototype
    image: /uploads/hero.jpg
  - type: text
    heading: About Us
    content: >-
      This is a text field and there are several elements we can add here. This
      is a paragraph and I can write and write and write. Lorem ipsum dolor sit
      amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut
      labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud
      exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis
      aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu
      fugiat nulla pariatur.


      And we can add more things. Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque laudantium, totam rem aperiam, eaque ipsa quae ab illo inventore veritatis et quasi architecto beatae vitae dicta sunt explicabo. Nemo enim ipsam voluptatem quia voluptas sit aspernatur aut odit aut fugit, sed quia consequuntur magni dolores eos qui ratione voluptatem sequi nesciunt.


      Make Paragraps


      * Add lists

      * another one

      * And more items to demonstrate the list functionality


      > This is a quote. At vero eos et accusamus et iusto odio dignissimos ducimus qui blanditiis praesentium voluptatum deleniti atque corrupti quos dolores et quas molestias excepturi sint occaecati cupiditate non provident.


      `let variable = "will this work?"`
  - type: gallery
    images:
      - /uploads/img1.jpg
      - /uploads/img2.jpg
      - /uploads/img3.jpg
---
